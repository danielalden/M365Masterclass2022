﻿# Set correct upn on all users
$domain = get-adforest |select upnsuffixes -ExpandProperty upnsuffixes
$Users=Get-ADuser -Filter * -SearchBase "OU=Users,OU=ACME,DC=CORP,DC=ACME,DC=COM"

Foreach ($user in $users){
    $upn = "$($user.GivenName.ToLower()).$($user.Surname.ToLower())@$($domain)"
    Set-ADUser -EmailAddress:$upn -Identity:$User.DistinguishedName -Server:"acme-dc01.corp.acme.com" -UserPrincipalName:$upn
    }

