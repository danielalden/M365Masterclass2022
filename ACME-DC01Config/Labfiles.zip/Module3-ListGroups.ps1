﻿# Replace variables
#Variables
$TenantId = "e19ed79d-01c3-4237-b381-4ef69af1236e"
$ApplicationId = "d15af2d5-4de6-4856-867b-fe15c5d3b527"
$Thumbprint = "CEB61DCD7B5CA4CC62DFF6605601828CF64FB1D2"

#Connect to AzureAD
Try {
    Write-Output 'Connecting to services'
    Connect-AzAccount -ApplicationId $ApplicationId -Tenant $TenantId -CertificateThumbprint $Thumbprint
    }
Catch {
    Write-Error -Message $_.Exception.Message
    #Hangup
    Disconnect-AzAccount | Out-null
    Break
}
Write-Output "Connect process done"
# Function
try {
    Write-Output 'List all groups'
    $groups = Get-AzADGroup
    Write-Output $groups.Displayname >> C:\Temp\AutomationWorkflow2022.txt
}
Catch {
    Write-Error -Message $_.Exception.Message
    #Hangup
    Disconnect-AzAccount | Out-null
}
