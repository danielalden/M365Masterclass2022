﻿#Connect to Azure AD
Connect-AzureAD



#Get all AD Users and populate with country attribute
$FIUsers = Get-ADUser -Filter * -SearchBase "OU=Users,OU=ACME,DC=CORP,DC=ACME,DC=COM" |select -First 20
Foreach ($user in $FIUsers){
    Set-ADUser -Identity $user.samaccountname -add @{msExchUsageLocation='FI';c='FI';CO='Finland';countrycode='246'}
}
$SEUsers = Get-ADUser -Filter * -SearchBase "OU=Users,OU=ACME,DC=CORP,DC=ACME,DC=COM" |select -Last 31
Foreach ($user in $SEUsers){
    Set-ADUser -Identity $user.samaccountname -add @{msExchUsageLocation='SE';c='SE';CO='Sweden';countrycode='752'}
}